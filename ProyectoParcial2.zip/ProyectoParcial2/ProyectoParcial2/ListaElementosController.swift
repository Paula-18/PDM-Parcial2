//
//  ViewController.swift
//  ProyectoParcial2
//
//  Created by Alumno on 10/12/21.
//  Copyright © 2021 Alumno. All rights reserved.
//

import UIKit

class ListaElementosController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return elementos.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let celda = tableView.dequeueReusableCell(withIdentifier: "celdaElemento") as! CeldaElementoController
        celda.lblNombre.text = elementos[indexPath.row].nombre
        celda.imgIcono.image = UIImage(named: elementos[indexPath.row].foto)
        
        return celda
    }
    
    
    var elementos : [Elemento] = []
    
    @IBOutlet weak var tvElementos: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        self.title = "Elementos de Genshin Impact"
        
        //Personaje(nombre: "Venti", titulo: "El Bardo Itinerante", region: "Mondstadt", afiliacion: "Ciudad de Mondstadt", arma: "Arco", constelacion: "Carmen Dei")
        
        elementos.append(Elemento(nombre: "Anemo", elemento: "Viento", region: "Mondstadt", arconte: "Barbatos", foto: "anemo", personajes: [Personaje(nombre: "Venti", titulo: "El Bardo Itinerante", region: "Mondstadt", afiliacion: "Ciudad de Mondstadt", arma: "Arco", constelacion: "Carmen Dei", fotoP: "venti"), Personaje(nombre: "Jean", titulo: "La Caballera Dandelion", region: "Mondstadt", afiliacion: "Caballeros de F.", arma: "Espada", constelacion: "Leo Menor", fotoP: "jean"), Personaje(nombre: "Sacarosa", titulo: "La Dulzura Inofensiva", region: "Mondstadt", afiliacion: "Caballeros de F.", arma: "Catalizador", constelacion: "Ampulla", fotoP: "sucrose"), Personaje(nombre: "Xiao", titulo: "El Guardián Yaksha", region: "Liyue", afiliacion: "Adeptus de Liyue", arma: "Lanza", constelacion: "Alatus Nemeseos", fotoP: "xiao"),Personaje(nombre: "K. Kazuha", titulo: "El Mensajero del Viento", region: "Inazuma", afiliacion: "Flota Crux M.", arma: "Espada", constelacion: "Acer Palmatum", fotoP: "kazuha"),Personaje(nombre: "Sayu", titulo: "La Tejón Ninja", region: "Inazuma", afiliacion: "Los Ocelos", arma: "Mandoble", constelacion: "Nyctereutes Minor", fotoP: "sayu")]))
        elementos.append(Elemento(nombre: "Geo",elemento: "Roca", region: "Liyue", arconte: "Morax", foto: "geo", personajes: [Personaje(nombre: "Zhongli", titulo: "El Vagabundo del Mundo mortal", region: "Liyue", afiliacion: "Ciudad de Liyue", arma: "Lanza", constelacion: "Lapis Dei", fotoP: "zhongli"), Personaje(nombre: "Noelle", titulo: "La Heroína no Reconocida", region: "Mondstadt", afiliacion: "Caballeros de F.", arma: "Mandoble", constelacion: "Parma Cordis", fotoP: "noelle"), Personaje(nombre: "Albedo", titulo: "El Príncipe de la Roca Caliza", region: "Mondstadt", afiliacion: "Caballeros de F.", arma: "Espada", constelacion: "Princeps Cretaceus", fotoP: "albedo"), Personaje(nombre: "Ninguang", titulo: "La Estrella en Eclipse", region: "Liyue", afiliacion: "Siete Estrellas de L.", arma: "Catalizador", constelacion: "Opus Aequilibrium", fotoP: "ningguang"), Personaje(nombre: "Gorou", titulo: "El General Canino", region: "Inazuma", afiliacion: "Tropas de Watatsumi", arma: "Arco", constelacion: "Canis Bellatoris", fotoP: "gorou"), Personaje(nombre: "A. Itto", titulo: "1er Gran Líder de la Banda A.", region: "Inazuma", afiliacion: "Banda Arataki", arma: "Mandoble", constelacion: "Taurus Iracundus", fotoP: "itto"),]))
        elementos.append(Elemento(nombre: "Electro",elemento: "Rayos", region: "Inazuma", arconte: "Beelzebul", foto: "electro", personajes: [Personaje(nombre: "Shogun Raiden", titulo: "La Entidad de la Eutimia", region: "Inazuma", afiliacion: "Ciudad de Inazuma", arma: "Lanza", constelacion: "Imperatrix Umbrosa", fotoP: "shougun"), Personaje(nombre: "Lisa", titulo: "La Bruja de las Rosas", region: "Mondstadt", afiliacion: "Caballeros de F.", arma: "Catalizador", constelacion: "Tempus Fugit", fotoP: "lisa"), Personaje(nombre: "Fischl", titulo: "La Princesa del Juicio", region: "Mondstadt", afiliacion: "Gremio de Aventureros", arma: "Arco", constelacion: "Corvus", fotoP: "fischl"), Personaje(nombre: "Razor", titulo: "El Niño-lobo", region: "Mondstadt", afiliacion: "Reino de los Lobos", arma: "Mandoble", constelacion: "Lupus Minor", fotoP: "razor"), Personaje(nombre: "Keching", titulo: "La Conductora del Trueno", region: "Liyue", afiliacion: "Siete Estrellas de L.", arma: "Espada", constelacion: "Trulla Cementarii", fotoP: "keqing"), Personaje(nombre: "Beidou", titulo: "La Reina del Océano si Corona", region: "Liyue", afiliacion: "Flota Crux M.", arma: "Mandoble", constelacion: "Victor Mare", fotoP: "beidou"), Personaje(nombre: "K. Sara", titulo: "La Arquera Plumanegra", region: "Inazuma", afiliacion: "Comisión Tenryou", arma: "Arco", constelacion: "Flabellum", fotoP: "sara")]))
        elementos.append(Elemento(nombre: "Dendro",elemento: "Plantas", region: "Sumeru", arconte: "Dios de la sabiduría", foto: "dendro", personajes: [Personaje(nombre: "Desconocido", titulo: "Desconocido", region: "Sumeru", afiliacion: "Ciudad de Sumeru", arma: "Desconocida", constelacion: "Desconocida", fotoP: "")]))
        elementos.append(Elemento(nombre: "Hydro",elemento: "Agua", region: "Fontaine", arconte: "Diosa de la justicia", foto: "hydro", personajes: [Personaje(nombre: "Bárbara", titulo: "La Ídolo Radiante", region: "Mondstadt", afiliacion: "Iglesia de Favonius", arma: "Catalizador", constelacion: "Cratus", fotoP: "barbara"), Personaje(nombre: "Mona", titulo: "La Observadora de los Astros", region: "Mondstadt", afiliacion: "Ciudad de Mondstadt", arma: "Catalizador", constelacion: "Astrolabos", fotoP: "mona"), Personaje(nombre: "Xingchiu", titulo: "El Joven Galante", region: "Liyue", afiliacion: "Gremio de Comerciantes", arma: "Espada", constelacion: "Fabulae Textile", fotoP: "xingqiu"), Personaje(nombre: "Tartaglia", titulo: "Nobile", region: "Snezhnaya", afiliacion: "Fatui", arma: "Arco", constelacion: "Monoceros Caeli", fotoP: "tartaglia"), Personaje(nombre: "S. Kokomi", titulo: "La Perla de la Sabiduría", region: "Inazuma", afiliacion: "Isla Watatsumi", arma: "Catalizador", constelacion: "Dracaena Somnolenta", fotoP: "kokomi")]))
        elementos.append(Elemento(nombre: "Pyro",elemento: "Fuego", region: "Natlán", arconte: "Diosa de la guerra", foto: "pyro", personajes: [Personaje(nombre: "Amber", titulo: "La Campeona de Vuelo", region: "Mondstadt", afiliacion: "Caballeros de F.", arma: "Arco", constelacion: "Lepus Minor", fotoP: "Amber"), Personaje(nombre: "Diluc", titulo: "El Amanecer Oscuro", region: "Mondstadt", afiliacion: "Viñedo del Amaneces", arma: "Mandoble", constelacion: "Noctua", fotoP: "Diluc"), Personaje(nombre: "Bennett", titulo: "El tentador del Destino", region: "Mondstadt", afiliacion: "Gremio de Aventureros", arma: "Espada", constelacion: "Rota Calamitas", fotoP: "Bennett"), Personaje(nombre: "Klee", titulo: "El Sol Fugitivo", region: "Mondstadt", afiliacion: "Caballeros de F.", arma: "Catalizador", constelacion: "Trifolium", fotoP: "Klee"), Personaje(nombre: "Xiangling", titulo: "La Maestra Culinaria de L.", region: "Liyue", afiliacion: "Restaurante Wanmin", arma: "Lanza", constelacion: "Trullae", fotoP: "Xiangling"), Personaje(nombre: "Xinyan", titulo: "La Melodía Incandescente", region: "Liyue", afiliacion: "Ciudad de Liyue", arma: "Mandoble", constelacion: "Fila Ignium", fotoP: "Xinyan"), Personaje(nombre: "Hu Tao", titulo: "La Guía del Más Allá", region: "Liyue", afiliacion: "Funeraria El Camino", arma: "Lanza", constelacion: "Papilio Charontis", fotoP: "Hutao"), Personaje(nombre: "Yanfei", titulo: "La Letrada Inocente", region: "Liyue", afiliacion: "Ciudad de Liyue", arma: "Catalizador", constelacion: "Bestia Iustitia", fotoP: "Yanfei"), Personaje(nombre: "Yoimiya", titulo: "La Maestra de las Llamas", region: "Inazuma", afiliacion: "Pirotecnia Naganohara", arma: "Arco", constelacion: "Carassius Auratus", fotoP: "Yoimiya"), Personaje(nombre: "Thoma", titulo: "El Protector de Tierras Lejanas", region: "Mondstadt(Natal), Inazuma", afiliacion: "Comisión Yashiro", arma: "Lanza", constelacion: "Rubeum Scuta", fotoP: "Thoma"),]))
        elementos.append(Elemento(nombre: "Cryo",elemento: "Hielo", region: "Snezhnaya", arconte: "La Zarina", foto: "cryo", personajes: [Personaje(nombre: "Kaeya", titulo: "El espadachín Glacial", region: "Mondstadt", afiliacion: "Caballeros de F.", arma: "Espada", constelacion: "Pavo Ocellus", fotoP: "kaeya"), Personaje(nombre: "Diona", titulo: "La Cantinera Felina", region: "Mondstadt", afiliacion: "Taberna Cola de Gato", arma: "Arco", constelacion: "Feles", fotoP: "diona"), Personaje(nombre: "Rosaria", titulo: "La Beata Impía", region: "Mondstadt", afiliacion: "Iglesia de Favonius", arma: "Lanza", constelacion: "Spinea Corona", fotoP: "rosaria"), Personaje(nombre: "Eula", titulo: "La Bailarina de las Olas", region: "Mondstadt", afiliacion: "Caballeros de F.", arma: "Mandoble", constelacion: "Apharos Delos", fotoP: "eula"), Personaje(nombre: "Chongyun", titulo: "El Hielo Ardiente", region: "Liyue", afiliacion: "Ciudad de Liyue", arma: "Mandoble", constelacion: "Nubis Caesor", fotoP: "chongyun"), Personaje(nombre: "Qiqi", titulo: "La Resurrección del Hielo", region: "Liyeu", afiliacion: "Farmacia Bubu", arma: "Espada", constelacion: "Pristina Nola", fotoP: "qiqi"), Personaje(nombre: "Ganyu", titulo: "La Vigía del Plenilunio", region: "Liyue", afiliacion: "Pabellón Yuehai", arma: "Arco", constelacion: "Sinae Unicornis", fotoP: "ganyu"), Personaje(nombre: "K. Ayaka", titulo: "La Garza de la Escarcha", region: "Inazuma", afiliacion: "Comisión Yashiro", arma: "Espada", constelacion: "Grus Nivis", fotoP: "ayaka"), Personaje(nombre: "Aloy", titulo: "La Salvadora de Otro Mundo", region: "De otro mundo", afiliacion: "Heroína Errante", arma: "Arco", constelacion: "Nora Fortis", fotoP: "aloy")]))
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let destino = segue.destination as! DetallesElementosController
        let destino2 = segue.destination as! DetallesElementosController
        destino.elemento = elementos[tvElementos.indexPathForSelectedRow!.row]
        destino2.personajes = elementos[tvElementos.indexPathForSelectedRow!.row].personajes
    }


}

