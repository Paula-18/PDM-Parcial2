//
//  Elemento.swift
//  ProyectoParcial2
//
//  Created by Pauna on 17/10/21.
//  Copyright © 2021 Alumno. All rights reserved.
//

import Foundation

class Elemento {
    
    var nombre = ""
    var elemento = ""
    var region = ""
    var arconte = ""
    var foto = ""
    
    var personajes : [Personaje] = []
    
    init(nombre: String, elemento: String, region: String, arconte: String, foto: String, personajes: [Personaje]) {
        self.nombre = nombre
        self.elemento = elemento
        self.region = region
        self.arconte = arconte
        self.foto = foto
        self.personajes = personajes
    }
    
}
