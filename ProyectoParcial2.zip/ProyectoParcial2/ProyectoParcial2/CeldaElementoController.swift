//
//  CeldaElementoController.swift
//  ProyectoParcial2
//
//  Created by Pauna on 17/10/21.
//  Copyright © 2021 Alumno. All rights reserved.
//

import Foundation

import UIKit

class CeldaElementoController : UITableViewCell {
    
    @IBOutlet weak var lblNombre: UILabel!
    @IBOutlet weak var imgIcono: UIImageView!
}
