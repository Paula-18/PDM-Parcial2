//
//  Personaje.swift
//  ProyectoParcial2
//
//  Created by Pauna on 19/10/21.
//  Copyright © 2021 Alumno. All rights reserved.
//

import Foundation

class Personaje {
    
    var nombre: String?
    var titulo: String?
    var region: String?
    var afiliacion: String?
    var arma: String?
    var constelacion: String?
    var fotoP: String?
    
    init(nombre: String, titulo: String, region: String, afiliacion: String, arma: String, constelacion: String, fotoP: String) {
        
        self.nombre = nombre
        self.titulo = titulo
        self.region = region
        self.afiliacion = afiliacion
        self.arma = arma
        self.constelacion = constelacion
        self.fotoP = fotoP
    }
    
}
