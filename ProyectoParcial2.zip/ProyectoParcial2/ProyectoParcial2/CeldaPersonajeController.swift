//
//  CeldaPersinajeController.swift
//  ProyectoParcial2
//
//  Created by Pauna on 19/10/21.
//  Copyright © 2021 Alumno. All rights reserved.
//

import Foundation
import UIKit

class CeldaPersonajeController : UITableViewCell {
    
    
    @IBOutlet weak var lblNom: UILabel!
    @IBOutlet weak var lblTitulo: UILabel!
    @IBOutlet weak var lblRegion: UILabel!
    @IBOutlet weak var lblAfiliacion: UILabel!
    @IBOutlet weak var lblArma: UILabel!
    @IBOutlet weak var lblConstelacion: UILabel!
    @IBOutlet weak var imgPersonaje: UIImageView!
    
}
