//
//  DetallesElementoController.swift
//  ProyectoParcial2
//
//  Created by Pauna on 17/10/21.
//  Copyright © 2021 Alumno. All rights reserved.
//

import Foundation
import UIKit

class DetallesElementosController : UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var tvPersonajes: UITableView!
    var personajes : [Personaje] = []
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return personajes.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let celdaDetalles = tableView.dequeueReusableCell(withIdentifier: "celdaPersonaje") as! CeldaPersonajeController
        
        celdaDetalles.lblNom.text = personajes[indexPath.row].nombre
        celdaDetalles.lblTitulo.text = personajes[indexPath.row].titulo
        celdaDetalles.lblRegion.text = personajes[indexPath.row].region
        celdaDetalles.lblAfiliacion.text = personajes[indexPath.row].afiliacion
        celdaDetalles.lblArma.text = personajes[indexPath.row].arma
        celdaDetalles.lblConstelacion.text = personajes[indexPath.row].constelacion
        celdaDetalles.imgPersonaje.image = UIImage(named: personajes[indexPath.row].fotoP!)
        
        return celdaDetalles
    }
    
    //Elementos del controller
    @IBOutlet weak var lblElementoSeleccionado: UILabel!
    @IBOutlet weak var lblRegionE: UILabel!
    @IBOutlet weak var lblArconteE: UILabel!
    @IBOutlet weak var imgLogo: UIImageView!
    
    
    
    var elemento : Elemento = Elemento(nombre: "", elemento: "", region: "", arconte: "", foto: "", personajes: [])
    
    override func viewDidLoad() {
        self.title = elemento.nombre
        
        lblElementoSeleccionado.text = elemento.elemento
        lblRegionE.text = elemento.region
        lblArconteE.text = elemento.arconte
        imgLogo.image = UIImage(named: elemento.foto)
    }
}
